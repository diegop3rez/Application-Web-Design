package com.example.act3;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ImageView imageView;
    private Button zoomButton;
    private float scaleFactor = 0.5f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        zoomButton = findViewById(R.id.button);

        zoomButton.setOnClickListener(v -> {
            scaleFactor = (scaleFactor == 0.5f) ? 1.0f : 0.5f;
            imageView.setScaleX(scaleFactor);
            imageView.setScaleY(scaleFactor);
        });
    }
}
